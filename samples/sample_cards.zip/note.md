#card Sample question

id:: c_sample

Sample answer.
