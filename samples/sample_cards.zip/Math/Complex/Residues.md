#card Residue calculus quick check
tags:: math, complex analysis

Inline sample: $f(z)=\frac{1}{(z-1)^2}$. Evaluate the contour integral below.

$$\oint_{\gamma} \frac{dz}{z-1} = 2\pi i.$$

\[
\begin{aligned}
\operatorname{Res}(f, a) &= \frac{1}{(m-1)!}\lim_{z \to a} \frac{d^{m-1}}{dz^{m-1}}\big[(z-a)^m f(z)\big]
\end{aligned}
\]

![Contour sketch](img/contour.png)
