#card Residue calculus quick check
tags:: math, complex analysis
<br>
Inline sample: $f(z)=
rac{1}{(z-1)^2}$. Evaluate the contour integral below.
<br>
$$\oint_{\gamma}
rac{dz}{z-1} = 2\pi i.$$
<br>
\[
egin{aligned}
\operatorname{Res}(f, a) &=
rac{1}{(m-1)!}\lim_{z 	o a}
rac{d^{m-1}}{dz^{m-1}}ig[(z-a)^m f(z)ig]
\end{aligned}
\]
<br>
![Contour sketch](img/contour.png)
