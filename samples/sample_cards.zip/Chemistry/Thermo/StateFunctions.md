Gibbs free energy balance #card
tags:: chemistry, thermo
<br>
The relationship $\Delta G = \Delta H - T\Delta S$ predicts spontaneity when the result is negative.
