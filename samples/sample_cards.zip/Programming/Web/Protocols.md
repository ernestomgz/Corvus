#card HTTP semantics snippet
tags:: programming, web, http

`GET` is both safe and idempotent. Example request:

```http
GET /notes HTTP/1.1
Host: example.dev
Accept: application/json
```

Follow RFC 9110 for more detail: https://www.rfc-editor.org/rfc/rfc9110

![Client/server flow](img/http_flow.png)
