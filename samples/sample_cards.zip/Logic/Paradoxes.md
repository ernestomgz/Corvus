## The Liar Statement #card
id:: logic-liar-1
tags:: logic, paradoxes

"![The Liar](img/liar.png)" asserts its own falsehood, so it can never stably be true or false.
