## Self-reference trap #card
id:: logic-liar-1
tags:: logic, paradoxes
<br>
This puzzle uses **bold text**, _italics_, inline code like `lambda self: not self()` and external references such as [Stanford Encyclopedia](https://plato.stanford.edu/entries/liar-paradox/).
<br>
Break the cycle by paraphrasing the statement until it stops referencing itself directly.
<br>
![Self-referential loop](img/liar.png)
