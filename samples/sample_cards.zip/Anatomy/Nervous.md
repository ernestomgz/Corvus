### Nodes of Ranvier #card
id:: anatomy-axon-2
tags:: anatomy; neuro

Saltatory conduction leaps between ![node diagram](../SharedMedia/brain.png) every few micrometers along the axon.
