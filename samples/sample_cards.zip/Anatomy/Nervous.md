### Nodes of Ranvier #card
id:: anatomy-axon-2
tags:: anatomy; neuro

Saltatory conduction leaps between successive nodes roughly every 1 um, allowing action potentials to regenerate efficiently.

![Axon schematic highlighting nodes](../../SharedMedia/brain.png)

- Myelin prevents ion leakage.
- Voltage-gated channels cluster at the exposed nodes.
