### Nodes of Ranvier #card
id:: anatomy-axon-2
tags:: anatomy; neuro
<br>
Saltatory conduction leaps between successive nodes roughly every 1 micrometer, allowing action potentials to regenerate efficiently.
<br>
![Axon schematic highlighting nodes](../../SharedMedia/brain.png)
<br>
- Myelin prevents ion leakage.
- Voltage-gated channels cluster at the exposed nodes.
