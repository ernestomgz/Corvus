#card Maxwell's fourth equation
tags:: physics, electromagnetism

Faraday's law can be written as $$\nabla \times \vec{E} = -\frac{\partial \vec{B}}{\partial t}$$.

The flux change induces a curl in the electric field.
![[EM/img/field.png]]
