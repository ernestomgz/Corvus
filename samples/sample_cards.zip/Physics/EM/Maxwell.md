#card Maxwell's fourth equation
            tags:: physics, electromagnetism
<br>
            Faraday's law can be written as $$
abla 	imes
ec{E} = -
rac{\partial
ec{B}}{\partial t}$$.
<br>
            The flux change induces a curl in the electric field.
            ![[EM/img/field.png]]
