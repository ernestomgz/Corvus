#card Maxwell's fourth equation
tags:: physics, electromagnetism

Faraday's law can be written as $$\nabla \times \vec{E} = -\frac{\partial \vec{B}}{\partial t}$$.

A field sketch:
![[EM/img/field.png]]
