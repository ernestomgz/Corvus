## Linkers for essays #card
tags:: spanish, writing
<br>
Use connectors to join ideas gracefully:
- **Por lo tanto** - therefore
- _Sin embargo_ - however
- [Ademas](https://dle.rae.es/ademas) adds supporting ideas.
![Connector grid](../../SharedMedia/connectors.png)
